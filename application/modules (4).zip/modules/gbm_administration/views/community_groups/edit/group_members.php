<div class="row">
	<div class="col-md-12">
		<a  class="btn btn-sm btn-success pull-right" id="open_new_tenant" onclick="get_new_tenant();" style="margin-left:5px">Add Member</a>
		<a  class="btn btn-sm btn-warning pull-right" id="close_new_tenant" style="display:none; margin-left:5px;" onclick="close_new_tenant();">Close member add</a>
	</div>
	
</div>
