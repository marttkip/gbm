		<section class="map-box">
        	<iframe width="100%" height="450" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d15955.283888087797!2d36.82172274530894!3d-1.2811310229756814!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2ske!4v1411319590582" width="600" height="450" frameborder="0" style="border:0"></iframe>
		</section>  <!-- /.map-box -->
        
		<section class="box">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
                    	<h2 class="text-center fancy-heading text-red"><span>Contact</span></h2>
                        
                        <p>
							I would love to here from you about your thoughts, opinions, suggestions or any other enquiries that you may have. Please feel free to contact me.
						</p>
                    </div>
                </div>
                
				<div class="row">
					<div class="col-md-6">
						<h3>On social media</h3>
						<br>
                        
						<ul class="clean-list contact-info white">
                            <li>
                            	<a href="https://www.facebook.com/InchesToStyle" target="_blank"><i class="icon-161"></i> InchesToStyle & Botique i2s</a>
                            </li>
                            
                            <li>
                            	<a href="https://twitter.com/InchesToStyle" target="_blank"><i class="icon-157"></i> InchesToStyle</a>
                            </li>
                            
                            <li>
                            	<a href="http://instagram.com/inchestostyle" target="_blank"><i class="icon-158"></i> inches2style</a>
                            </li>
                            
                            <li>
                            	<a href="https://plus.google.com/+AudreyMasitsa?prsrc=5" target="_blank"><i class="icon-167"></i> +AudreyMasitsa</a>
                            </li>
                            
                            <li>
                            	<a href="http://pinterest.com/audreym23" target="_blank"><i class="icon-107"></i> audreym23</a>
                            </li>
                            
                            <li>
                            	<a href="http://www.bloglovin.com/en/blog/3483135/inches-to-style" target="_blank">Bloglovin`</a>
                            </li>
						</ul>
					</div>
					<div class="col-md-6">
						<h3>Contact details</h3>
						<br>
						<ul class="clean-list contact-info white">
							<li><b>E-mail: </b> <a href="mailto:inchestostyle@gmail.com ">inchestostyle@gmail.com </a></li>
							<li><b>Phone: </b> <a href="tel:+254705925498">+254 705 925 498 </a></li>
						</ul>
					</div>
				</div>
			</div>
		</section>