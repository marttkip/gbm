<div class="widget boxed">

                    <div class="widget-head">
                        <h4 class="pull-left"><i class="icon-reorder"></i>Condensed Table</h4>
                        <div class="widget-icons pull-right">
                            <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a>
                            <a href="#" class="wclose"><i class="icon-remove"></i></a>
                        </div>
                        <div class="clearfix"></div>
                    </div>

                    <div class="widget-content">

                        <table class="table table-hover table-striped">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Location</th>
                                <th>Date</th>
                                <th>Type</th>
                            </tr>
                            </thead>
                            <tbody>

                            <tr>
                                <td>1</td>
                                <td>Ravi Kumar</td>
                                <td>India</td>
                                <td>23/12/2012</td>
                                <td>Paid</td>
                            </tr>


                            <tr>
                                <td>2</td>
                                <td>Parneethi Chopra</td>
                                <td>USA</td>
                                <td>13/02/2012</td>
                                <td>Free</td>
                            </tr>

                            <tr>
                                <td>3</td>
                                <td>Kumar Ragu</td>
                                <td>Japan</td>
                                <td>12/03/2012</td>
                                <td>Paid</td>
                            </tr>

                            <tr>
                                <td>4</td>
                                <td>Vishnu Vardan</td>
                                <td>Bangkok</td>
                                <td>03/11/2012</td>
                                <td>Paid</td>
                            </tr>

                            <tr>
                                <td>5</td>
                                <td>Anuksha Sharma</td>
                                <td>Singapore</td>
                                <td>13/32/2012</td>
                                <td>Free</td>
                            </tr>

                            </tbody>
                        </table>

                    </div>

                </div>